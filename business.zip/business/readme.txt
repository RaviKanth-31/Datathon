This is the information about the columns in the Agriculture Dataset.
Date
Open- Opening stock price of the day
High- Highest stock price of the day
Low- Loweset stock price of the day
Close- Last traded price of the day
Adj Close- Closing price of the day
Volume- Volume of stock traded on the day