This is the information about the columns in the Agriculture Dataset.
N- Nitrogen
P- Phosporous
K- Potassium
Temperature
Humidity
Ph
Ranifall
label - Which type of crop was grown on these conditions